import React, { useState } from "react";

// Основной компонент для работы с реальными данными Waves
const RealDataDemo = () => {
  // Состояния для управления данными и интерфейсом
  const [address, setAddress] = useState("");
  const [balance, setBalance] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [history, setHistory] = useState([]);

  // Функция для проверки корректности адреса Waves
  const isValidWavesAddress = (addr) => {
    // Базовая проверка: адрес Waves обычно начинается с '3' и имеет 35 символов
    return addr && addr.length === 35 && addr.startsWith('3');
  };

  // Основная функция для получения баланса
  const handleFetchBalance = async () => {
    // Проверяем корректность введенного адреса
    if (!address.trim()) {
      setError("Пожалуйста, введите адрес");
      return;
    }

    if (!isValidWavesAddress(address.trim())) {
      setError("Некорректный формат адреса Waves. Адрес должен начинаться с '3' и содержать 35 символов");
      return;
    }

    // Устанавливаем состояние загрузки
    setLoading(true);
    setError("");
    setBalance(null);

    try {
      // Отправляем запрос к нашему Flask API
      const response = await fetch(`/real/balance/${address.trim()}`);
      const data = await response.json();

      if (data.success) {
        // Успешно получили данные
        setBalance(data.balance);
        
        // Добавляем запрос в историю
        setHistory(prev => [{
          address: data.address,
          balance: data.balance,
          timestamp: new Date().toLocaleString('ru-RU')
        }, ...prev.slice(0, 4)]); // Храним только последние 5 запросов
      } else {
        // Обрабатываем ошибку от API
        setError(data.error || "Неизвестная ошибка");
      }
    } catch (err) {
      // Обрабатываем ошибки сети или парсинга
      console.error("Ошибка запроса:", err);
      setError("Ошибка соединения с сервером. Убедитесь, что Flask сервер запущен на порту 5000");
    } finally {
      setLoading(false);
    }
  };

  // Функция для очистки формы
  const handleClear = () => {
    setAddress("");
    setBalance(null);
    setError("");
  };

  // Функция для быстрого выбора адреса из истории
  const selectFromHistory = (historyAddress) => {
    setAddress(historyAddress);
    setError("");
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-lg">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">
          Проверка баланса Waves
        </h2>
        <p className="text-gray-600">
          Введите адрес кошелька Waves для получения актуального баланса из блокчейна
        </p>
      </div>

      {/* Основная форма для ввода адреса */}
      <div className="mb-6">
        <div className="flex flex-col sm:flex-row gap-3 mb-4">
          <input
            className="flex-1 border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            type="text"
            placeholder="Введите адрес Waves (например: 3P...)"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            disabled={loading}
          />
          <div className="flex gap-2">
            <button
              onClick={handleFetchBalance}
              disabled={loading || !address.trim()}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
            >
              {loading ? "Загружается..." : "Проверить баланс"}
            </button>
            <button
              onClick={handleClear}
              className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
            >
              Очистить
            </button>
          </div>
        </div>

        {/* Показываем подсказку о формате адреса */}
        <p className="text-sm text-gray-500">
          💡 Адрес Waves должен начинаться с "3" и содержать 35 символов
        </p>
      </div>

      {/* Отображение ошибок */}
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
          <div className="flex items-center">
            <span className="text-red-600 mr-2">⚠️</span>
            <p className="text-red-700">{error}</p>
          </div>
        </div>
      )}

      {/* Отображение результата */}
      {balance !== null && !loading && (
        <div className="mb-6 p-6 bg-green-50 border border-green-200 rounded-lg">
          <h3 className="text-lg font-semibold text-green-800 mb-2">
            ✅ Баланс успешно получен
          </h3>
          <div className="text-green-700">
            <p><strong>Адрес:</strong> <code className="bg-green-100 px-2 py-1 rounded text-sm">{address}</code></p>
            <p><strong>Баланс:</strong> <span className="text-2xl font-bold">{balance.toFixed(8)}</span> WAVES</p>
            <p className="text-sm mt-2">
              💰 Примерно {(balance * 2.5).toFixed(2)} USD (условный курс)
            </p>
          </div>
        </div>
      )}

      {/* История запросов */}
      {history.length > 0 && (
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-3">
            📋 История запросов
          </h3>
          <div className="space-y-2">
            {history.map((item, index) => (
              <div
                key={index}
                className="flex justify-between items-center p-3 bg-gray-50 rounded-lg border hover:bg-gray-100 transition-colors"
              >
                <div className="flex-1">
                  <p className="font-mono text-sm text-gray-700">
                    {item.address.substring(0, 10)}...{item.address.substring(25)}
                  </p>
                  <p className="text-xs text-gray-500">{item.timestamp}</p>
                </div>
                <div className="text-right mr-3">
                  <p className="font-semibold">{item.balance.toFixed(4)} WAVES</p>
                </div>
                <button
                  onClick={() => selectFromHistory(item.address)}
                  className="px-3 py-1 text-sm bg-blue-100 text-blue-700 rounded hover:bg-blue-200 transition-colors"
                >
                  Выбрать
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Информационный блок */}
      <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <h4 className="font-semibold text-blue-800 mb-2">ℹ️ Информация</h4>
        <div className="text-blue-700 text-sm space-y-1">
          <p>• Данные получаются в реальном времени из официальной ноды Waves</p>
          <p>• Баланс отображается в токенах WAVES (не в wavelets)</p>
          <p>• Для работы необходимо запустить Flask сервер на localhost:5000</p>
          <p>• Примеры адресов можно найти в Waves Explorer</p>
        </div>
      </div>
    </div>
  );
};

// Главный компонент приложения
const App = () => {
  return (
    <div className="min-h-screen bg-gray-100 py-8">
      <div className="container mx-auto px-4">
        <header className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            🏦 Cryptobank
          </h1>
          <p className="text-xl text-gray-600">
            Просмотр данных блокчейна Waves в реальном времени
          </p>
        </header>
        
        <main>
          <RealDataDemo />
        </main>

        <footer className="text-center mt-12 text-gray-500 text-sm">
          <p>© 2025 Cryptobank | Работа с официальным API Waves Platform</p>
        </footer>
      </div>
    </div>
  );
};

export default App;
