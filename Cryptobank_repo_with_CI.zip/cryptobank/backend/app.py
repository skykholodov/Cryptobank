# app.py
from flask import Flask, Blueprint, request, jsonify
from flask_cors import CORS
import requests
import logging
from dotenv import load_dotenv
import os

# load .env
load_dotenv()

# Создаем главное Flask приложение
app = Flask(__name__)
CORS(app)  # Включаем CORS для работы с React фронтендом

# Настраиваем логирование для отладки
logging.basicConfig(level=logging.INFO)

# Константы для работы с Waves API
NODE_URL = os.getenv("NODE_URL", "https://nodes.wavesnodes.com")

# === Blueprint для работы с реальными данными Waves ===
real_wx_api_bp = Blueprint('real_wx_api', __name__)

@real_wx_api_bp.route('/real/balance/<address>', methods=['GET'])
def get_real_balance(address):
    """
    Получает реальный баланс WAVES для указанного адреса
    Аргументы:
        address (str): Адрес кошелька Waves
    Возвращает:
        JSON с балансом или сообщением об ошибке
    """
    try:
        # Отправляем запрос к официальной ноде Waves
        balance_response = requests.get(f"{NODE_URL}/addresses/balance/{address}", timeout=10)
        
        if balance_response.status_code == 200:
            balance_data = balance_response.json()
            # Конвертируем из wavelets в WAVES (делим на 100,000,000)
            waves_balance = balance_data.get('balance', 0) / 100_000_000
            
            return jsonify({
                "success": True,
                "address": address,
                "balance": waves_balance,
                "currency": "WAVES"
            })
        else:
            return jsonify({
                "success": False,
                "error": "Адрес не найден или недоступен"
            }), 404
            
    except requests.exceptions.Timeout:
        return jsonify({
            "success": False,
            "error": "Превышено время ожидания ответа от ноды"
        }), 408
        
    except requests.exceptions.RequestException as e:
        app.logger.error(f"Ошибка при запросе к ноде: {e}")
        return jsonify({
            "success": False,
            "error": "Ошибка соединения с блокчейн нодой"
        }), 500
        
    except Exception as e:
        app.logger.error(f"Неожиданная ошибка: {e}")
        return jsonify({
            "success": False,
            "error": "Внутренняя ошибка сервера"
        }), 500

@real_wx_api_bp.route('/real/address/<address>/data', methods=['GET'])
def get_address_data(address):
    """
    Получает дополнительную информацию об адресе
    """
    try:
        # Получаем данные адреса
        data_response = requests.get(f"{NODE_URL}/addresses/data/{address}", timeout=10)
        
        if data_response.status_code == 200:
            address_data = data_response.json()
            return jsonify({
                "success": True,
                "address": address,
                "data": address_data
            })
        else:
            return jsonify({
                "success": False,
                "error": "Данные адреса не найдены"
            }), 404
            
    except Exception as e:
        app.logger.error(f"Ошибка получения данных адреса: {e}")
        return jsonify({
            "success": False,
            "error": "Ошибка получения данных"
        }), 500

# === Blueprint для демо-данных (если нужен) ===
wx_api_bp = Blueprint('wx_api', __name__)

@wx_api_bp.route('/demo/balance', methods=['GET'])
def get_demo_balance():
    """Возвращает демо-данные для тестирования"""
    return jsonify({
        "success": True,
        "balance": 123.45,
        "currency": "WAVES",
        "note": "Это демо-данные"
    })

# === Blueprint для пользователей (базовый) ===
user_bp = Blueprint('user', __name__)

@user_bp.route('/user/favorites', methods=['GET', 'POST'])
def handle_favorites():
    """Базовая заглушка для работы с избранными адресами"""
    if request.method == 'GET':
        return jsonify({
            "success": True,
            "favorites": []
        })
    else:
        return jsonify({
            "success": True,
            "message": "Функция в разработке"
        })

# === Основной маршрут ===
@app.route('/')
def index():
    """Главная страница API"""
    return jsonify({
        "message": "Cryptobank API для работы с Waves blockchain",
        "version": "1.0",
        "endpoints": {
            "/real/balance/<address>": "Получить баланс адреса",
            "/real/address/<address>/data": "Получить данные адреса",
            "/demo/balance": "Демо-данные"
        }
    })

# === Обработка ошибок ===
@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "success": False,
        "error": "Эндпоинт не найден"
    }), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({
        "success": False,
        "error": "Внутренняя ошибка сервера"
    }), 500

# === Регистрация всех Blueprint ===
app.register_blueprint(real_wx_api_bp)
app.register_blueprint(wx_api_bp)
app.register_blueprint(user_bp)

# === Запуск приложения ===
if __name__ == "__main__":
    print("🚀 Запуск Cryptobank API сервера...")
    print("📍 Доступные эндпоинты:")
    print("   - GET / - Информация об API")
    print("   - GET /real/balance/<address> - Баланс адреса")
    print("   - GET /real/address/<address>/data - Данные адреса")
    print("   - GET /demo/balance - Демо-данные")
    
    app.run(
        debug=True,
        host='0.0.0.0',
        port=int(os.getenv("PORT", 5000))
    )
