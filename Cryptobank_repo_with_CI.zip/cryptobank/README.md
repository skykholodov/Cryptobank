# 🏦 Cryptobank

Полноценный стек: **Flask API** + **React (Vite)** + **Docker + NGINX**.

## Быстрый старт (локально)

### Backend
```bash
cd backend
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
python app.py
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

Откройте: http://localhost:3000

## Docker продакшен

```bash
docker compose up -d --build
```

Frontend: `http://<SERVER_IP>/`  
API проксируется через NGINX по путям `/real`, `/demo`, `/user`.

## Структура
```
backend/         # Flask API
frontend/        # React (Vite + Tailwind)
nginx/           # NGINX конфиг
Dockerfile.*     # Docker билды
docker-compose.yml
```

## Безопасность
- Никогда не публикуйте персональные токены GitHub в открытых местах.
- Сразу отзывайте случайно опубликованные токены.
